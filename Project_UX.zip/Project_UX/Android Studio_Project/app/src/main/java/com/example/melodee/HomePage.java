package com.example.melodee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.mbms.MbmsErrors;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class HomePage extends AppCompatActivity {

    private ImageView home;
    private ImageView aboutUs;
    private ImageView album;
    private ImageView logOut;
    private TextView user;
    ViewFlipper viewFlipper;

    int[] images  = {
            R.drawable.andsoitbegins,
            R.drawable.butter,
            R.drawable.lost_cause
    };

    String[] title1 = {
            "And So It Begins",
            "Butter",
            "Lost Cause"
    };

    String[] artist1 = {
            "Eva Celia",
            "BTS",
            "Billie Eilish"
    };

    String[] genre1 = {
            "Jazz",
            "POP",
            "LoPOP"
    };

    String[] money1 = {
            "Rp. 54.000,00",
            "Rp. 60.000,00",
            "Rp. 57.000,00"
    };

    String[] sold1 = {
            "220/300",
            "250/300",
            "215/300"
    };

    int[] covers1 = {
            R.drawable.andsoitbegins,
            R.drawable.butter,
            R.drawable.lost_cause
    };

    ListView list2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        init();
        String username = getIntent().getStringExtra("USERNAME_KEY");
        user.setText(username);
        doButtonListener();
        viewFlipper = findViewById(R.id.carousel);

        for(int image : images){
            sliderImages(image);
        }

        list2 = findViewById(R.id.list);

        CustomAdapter1 adapter1 = new CustomAdapter1();
        list2.setAdapter(adapter1);

        list2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), "you've click on " + title1[position], Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(HomePage.this, AlbumDetailPage.class);
                intent.putExtra("ARTIST_NAME", artist1[position]);
                intent.putExtra("TITLE_NAME", title1[position]);
                intent.putExtra("CATEGORY", genre1[position]);
                intent.putExtra("PRICE", money1[position]);
                intent.putExtra("TOTAL_SOLD", sold1[position]);
                intent.putExtra("IMAGE_ALBUM", covers1[position]);
                startActivity(intent);
            }
        });
    }

    public void sliderImages(int image){
        ImageView imageView = new ImageView(HomePage.this);
        imageView.setBackgroundResource(image);

        viewFlipper.addView(imageView);
        viewFlipper.setFlipInterval(3000);
        viewFlipper.setAutoStart(true);

        viewFlipper.setInAnimation(HomePage.this, android.R.anim.fade_in);
        viewFlipper.setOutAnimation(HomePage.this, android.R.anim.fade_out);
    }

    private void doButtonListener(){
        this.home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, HomePage.class);
                intent.putExtra("USERNAME_KEY", user.getText().toString());
                startActivity(intent);
            }
        });

        this.aboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, AboutUsPage.class);
                intent.putExtra("USERNAME_KEY", user.getText().toString());
                startActivity(intent);
            }
        });

        this.album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, AlbumPage.class);
                startActivity(intent);
            }
        });

        this.logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, LoginPage.class);
                startActivity(intent);
            }
        });
    }


    private void init(){
        this.user = findViewById(R.id.Text1);
        this.home = findViewById(R.id.homeBtn);
        this.aboutUs = findViewById(R.id.AboutUsBtn);
        this.album = findViewById(R.id.albumBtn);
        this.logOut = findViewById(R.id.LogOutBtn);
    }

    class CustomAdapter1 extends BaseAdapter {

        @Override
        public int getCount() {
            return covers1.length;
        }

        @Override
        public Object getItem(int position) {

            return null;
        }

        @Override
        public long getItemId(int position) {

            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.customer_list, null);
            ImageView imageView = convertView.findViewById(R.id.album1);
            TextView arts = convertView.findViewById(R.id.artist1);
            TextView title_album = convertView.findViewById(R.id.title1);
            TextView category_album = convertView.findViewById(R.id.category1);
            TextView price_album = convertView.findViewById(R.id.price1);
            TextView sold_album = convertView.findViewById(R.id.totalSold1);

            imageView.setImageResource(covers1[position]);
            arts.setText(artist1[position]);
            title_album.setText(title1[position]);
            category_album.setText(genre1[position]);
            price_album.setText(money1[position]);
            sold_album.setText(sold1[position]);

            return convertView;
        }
    }
}
package com.example.melodee;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

public class AboutUsPage extends AppCompatActivity {

    private TextView user;
    ViewPager page;
    TabLayout layout;
    TabItem tab1, tab2;
    PagerAdapter pagerAdapter;
    private ImageView home;
    private ImageView aboutUs;
    private ImageView album;
    private ImageView logOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us_page);

        init();
        String username = getIntent().getStringExtra("USERNAME_KEY");
        user.setText(username);
        doButtonListener();


        pagerAdapter = new PageAdapter(getSupportFragmentManager(), layout.getTabCount());
        page.setAdapter(pagerAdapter);

        layout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                page.setCurrentItem(tab.getPosition());
                pagerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        page.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(layout));
    }

    private void doButtonListener(){
        this.home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutUsPage.this, HomePage.class);
                intent.putExtra("USERNAME_KEY", user.getText().toString());
                startActivity(intent);
            }
        });

        this.aboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutUsPage.this, AboutUsPage.class);
                intent.putExtra("USERNAME_KEY", user.getText().toString());
                startActivity(intent);
            }
        });

        this.album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutUsPage.this, AlbumPage.class);
                startActivity(intent);
            }
        });

        this.logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutUsPage.this, LoginPage.class);
                startActivity(intent);
            }
        });
    }

    private void init(){
        this.user = findViewById(R.id.Text1);
        this.layout = findViewById(R.id.tabLayout);
        this.tab1 = findViewById(R.id.infoTxt);
        this.tab2 = findViewById(R.id.petaTxt);
        this.page = findViewById(R.id.pager);
        this.home = findViewById(R.id.homeBtn);
        this.aboutUs = findViewById(R.id.AboutUsBtn);
        this.album = findViewById(R.id.albumBtn);
        this.logOut = findViewById(R.id.LogOutBtn);
    }
}
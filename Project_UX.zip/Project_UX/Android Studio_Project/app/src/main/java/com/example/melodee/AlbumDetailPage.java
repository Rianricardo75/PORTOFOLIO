package com.example.melodee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;

public class AlbumDetailPage extends AppCompatActivity {

    private TextView artist_name;
    private TextView album_name;
    private TextView genre_name;
    private TextView price;
    private TextView sold_out;
    private ImageView cover_album;
    private TextView artist_name1;
    private TextView album_name1;
    private TextView genre_name1;
    private TextView price1;
    private TextView sold_out1;
    private ImageView cover_album1;
    private Button back;
    private Button buy;

    int final_quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_detail_page);

        init ();
        doButtonListener();

        String artist1 = getIntent().getStringExtra("ARTIST_NAME");
        artist_name.setText(artist1);
        String title1 = getIntent().getStringExtra("TITLE_NAME");
        album_name.setText(title1);
        String genre1 = getIntent().getStringExtra("CATEGORY");
        genre_name.setText(genre1);
        String money1 = getIntent().getStringExtra("PRICE");
        price.setText(money1);
        String sold1 = getIntent().getStringExtra("TOTAL_SOLD");
        sold_out.setText(sold1);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null){
            int img = bundle.getInt("IMAGE_ALBUM");

            cover_album.setImageResource(img);
        }

        String artist = getIntent().getStringExtra("ARTIST_NAME1");
        artist_name1.setText(artist);
        String title = getIntent().getStringExtra("TITLE_NAME1");
        album_name1.setText(title);
        String genre = getIntent().getStringExtra("CATEGORY1");
        genre_name1.setText(genre);
        String money = getIntent().getStringExtra("PRICE1");
        price1.setText(money);
        String sold = getIntent().getStringExtra("TOTAL_SOLD1");
        sold_out1.setText(sold);

        Bundle bundle1 = getIntent().getExtras();
        if (bundle1 != null){
            int img1 = bundle1.getInt("IMAGE_ALBUM1");

            cover_album1.setImageResource(img1);
        }

        NumberPicker numberPicker = findViewById(R.id.picker);

        numberPicker.setMaxValue(300);
        numberPicker.setMinValue(0);
        numberPicker.setValue(0);

        final_quantity = 0;

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                final_quantity = newVal;
            }
        });
    }

    private void doButtonListener() {
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlbumDetailPage.this, HomePage.class);
                startActivity(intent);
            }
        });

        this.buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (final_quantity == 0){
                    openDialog();
                } else {
                    openDialog1();
                }
            }
        });
    }

    public void openDialog (){
        DialogClass dialogClass = new DialogClass();
        dialogClass.show(getSupportFragmentManager(), "dialog");
    }

    public void openDialog1 (){
        DialogClass1 dialogClass1 = new DialogClass1();
        dialogClass1.show(getSupportFragmentManager(), "dialog");
    }

    public void init() {
        this.artist_name = findViewById(R.id.nma_artis);
        this.album_name = findViewById(R.id.jdl_album);
        this.genre_name = findViewById(R.id.genre);
        this.price = findViewById(R.id.hrg_album);
        this.sold_out = findViewById(R.id.ttl_sold);
        this.cover_album = findViewById(R.id.fto_album);
        this.artist_name1 = findViewById(R.id.nma_artis1);
        this.album_name1 = findViewById(R.id.jdl_album1);
        this.genre_name1 = findViewById(R.id.genre1);
        this.price1 = findViewById(R.id.hrg_album1);
        this.sold_out1 = findViewById(R.id.ttl_sold1);
        this.cover_album1 = findViewById(R.id.fto_album1);
        this.back = findViewById(R.id.backBtn);
        this.buy = findViewById(R.id.buyBtn);
    }
}
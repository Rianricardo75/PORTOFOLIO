package com.example.melodee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginPage extends AppCompatActivity {
    private EditText username, password;
    private TextView lblError;
    private Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        init();
        doButtonListener();


    }

    private void doButtonListener (){
        this.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validateInput();
            }
        });
    }

    private void validateInput(){
        if (this.username.length() == 0){
            this.lblError.setText("Username must be filled");
        }
        else if (this.password.getText().toString().equals("")){
            this.lblError.setText("Password must be filled");
        }

        else {
            this.lblError.setText("");
            Intent intent = new Intent(LoginPage.this, HomePage.class);
            intent.putExtra("USERNAME_KEY", username.getText().toString());
            startActivity(intent);
        }
    }

    private void init(){
        this.username = findViewById(R.id.usernameText);
        this.password = findViewById(R.id.passTxt);
        this.lblError = findViewById(R.id.errorlbl);
        this.loginBtn = findViewById(R.id.Loginbtn);
    }
}
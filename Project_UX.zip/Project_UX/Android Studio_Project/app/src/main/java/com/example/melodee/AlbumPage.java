package com.example.melodee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class AlbumPage extends AppCompatActivity {

    private ImageView home;
    private ImageView aboutUs;
    private ImageView album;
    private ImageView logOut;

    String[] title = {
            "And So It Begins",
            "Butter",
            "Lost Cause",
            "Choker",
            "Evermore"

    };

    String[] artist = {
            "Eva Celia",
            "BTS",
            "Billie Eilish",
            "Twenty One Pilots",
            "Taylor Swift"
    };

    String[] genre = {
            "Jazz",
            "POP",
            "LoPOP",
            "Rock",
            "Acoustic"
    };

    String[] money = {
            "Rp. 54.000,00",
            "Rp. 60.000,00",
            "Rp. 57.000,00",
            "Rp. 61.000,00",
            "Rp. 53.000,00"
    };

    String[] sold = {
            "220/300",
            "250/300",
            "215/300",
            "230/200",
            "200/300"
    };

    int[] covers = {
            R.drawable.andsoitbegins,
            R.drawable.butter,
            R.drawable.lost_cause,
            R.drawable.chocker,
            R.drawable.evermore
    };

    ListView list1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_page);

        init();
        doButtonListener();
        list1 = findViewById(R.id.list);

        CustomAdapter adapter = new CustomAdapter();
        list1.setAdapter(adapter);

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), "you've click on " + title[position], Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AlbumPage.this, AlbumDetailPage.class);
                intent.putExtra("ARTIST_NAME1", artist[position]);
                intent.putExtra("TITLE_NAME1", title[position]);
                intent.putExtra("CATEGORY1", genre[position]);
                intent.putExtra("PRICE1", money[position]);
                intent.putExtra("TOTAL_SOLD1", sold[position]);
                intent.putExtra("IMAGE_ALBUM1", covers[position]);
                startActivity(intent);
            }
        });

    }


    private void doButtonListener() {
        this.home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlbumPage.this, HomePage.class);
                startActivity(intent);
            }
        });

        this.aboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlbumPage.this, AboutUsPage.class);
                startActivity(intent);
            }
        });

        this.album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlbumPage.this, AlbumPage.class);
                startActivity(intent);
            }
        });

        this.logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlbumPage.this, LoginPage.class);
                startActivity(intent);
            }
        });
    }

    private void init() {
        this.home = findViewById(R.id.homeBtn);
        this.aboutUs = findViewById(R.id.AboutUsBtn);
        this.album = findViewById(R.id.albumBtn);
        this.logOut = findViewById(R.id.LogOutBtn);
    }

    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return covers.length;
        }

        @Override
        public Object getItem(int position) {

            return null;
        }

        @Override
        public long getItemId(int position) {

            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.list_custom, null);
            ImageView imageView = convertView.findViewById(R.id.album);
            TextView arts = convertView.findViewById(R.id.artist);
            TextView title_album = convertView.findViewById(R.id.title);
            TextView category_album = convertView.findViewById(R.id.category);
            TextView price_album = convertView.findViewById(R.id.price);
            TextView sold_album = convertView.findViewById(R.id.totalSold);

            imageView.setImageResource(covers[position]);
            arts.setText(artist[position]);
            title_album.setText(title[position]);
            category_album.setText(genre[position]);
            price_album.setText(money[position]);
            sold_album.setText(sold[position]);

            return convertView;
        }
    }
}